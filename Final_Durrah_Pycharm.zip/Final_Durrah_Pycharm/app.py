# Importing Flask and other necessary libraries
from flask import Flask, request, jsonify, render_template
import joblib
import logging
import pandas as pd
from sklearn.preprocessing import StandardScaler

# Initialize the Flask application
app = Flask(__name__)

# Set up logging
logging.basicConfig(level=logging.INFO)

# Load the model
model_path = 'final_hdb_model.pkl'  # Replace with your actual model path
try:
    model = joblib.load(model_path)
    logging.info("Model loaded successfully.")
except Exception as e:
    logging.error(f"Error loading model: {e}")

# Initialize the scaler for normalization
scaler = StandardScaler()

# Define the home route
@app.route('/')
def home():
    return render_template('index.html')

# Function to preprocess features
def preprocess_features(features):
    # Create a DataFrame from the input features
    df = pd.DataFrame([features], columns=[
        'block', 'street_name', 'town', 'flat_type', 'storey_range', 'flat_model', 'postal_code', 'floor_area_sqm'
    ])

    # One-hot encoding for categorical features
    df_encoded = pd.get_dummies(df, columns=['street_name', 'town', 'flat_type', 'storey_range', 'flat_model'])

    # Ensure the DataFrame has the same columns as the model expects
    expected_columns = model.feature_names_in_  # Get the expected columns directly from the model
    df_encoded = df_encoded.reindex(columns=expected_columns, fill_value=0)

    # Normalize the 'floor_area_sqm' feature
    df_encoded[['floor_area_sqm']] = scaler.fit_transform(df_encoded[['floor_area_sqm']])

    return df_encoded.values.flatten()  # Return a flat array of features

# Define a function to dynamically adjust predictions
def adjust_prediction(prediction):
    # Example dynamic adjustment logic (this can be refined)
    adjustment_factor = 1.1  # Modify based on your analysis
    return prediction * adjustment_factor

# Define the prediction route
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get the JSON data from the request
        data = request.get_json()

        # Validate required fields and their types
        required_fields = ['block', 'street_name', 'town', 'flat_type', 'storey_range', 'flat_model', 'postal_code', 'floor_area_sqm']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing field: {field}'}), 400

        # Extract features from the JSON data
        features = [
            data['block'],
            data['street_name'],
            data['town'],
            data['flat_type'],
            data['storey_range'],
            data['flat_model'],
            int(data['postal_code']),
            float(data['floor_area_sqm'])
        ]

        # Basic validation
        if not isinstance(features[6], int) or features[6] <= 0:
            return jsonify({'error': 'postal_code must be a positive integer'}), 400
        if not isinstance(features[7], float) or features[7] <= 0:
            return jsonify({'error': 'floor_area_sqm must be a positive float'}), 400

        # Preprocess features
        processed_features = preprocess_features(features)

        # Log processed features for debugging
        logging.info(f"Processed features for prediction: {processed_features}")

        # Make the prediction
        prediction = model.predict([processed_features])

        # Adjust the prediction dynamically
        adjusted_prediction = adjust_prediction(prediction[0])

        # Log the original and adjusted predictions
        logging.info(f"Original prediction: {prediction[0]}, Adjusted prediction: {adjusted_prediction}")

        # Format the adjusted prediction as a string with a dollar sign
        formatted_prediction = "${:,.0f}".format(adjusted_prediction)

        # Return the formatted prediction result
        return jsonify({'prediction': formatted_prediction})

    except ValueError as ve:
        logging.error(f"Value error: {ve}")
        return jsonify({'error': str(ve)}), 400
    except Exception as e:
        logging.error(f"Error during prediction: {e}")
        return jsonify({'error': str(e)}), 500

# Run the application
if __name__ == '__main__':
    app.run(debug=True)

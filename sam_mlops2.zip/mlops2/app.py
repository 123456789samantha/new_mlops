

from flask import Flask, request, render_template
import pandas as pd
from pycaret.anomaly import load_model, predict_model

app = Flask(__name__)

# Load the PyCaret model
model = load_model(r'C:\Users\Lenovo\Desktop\skool1\y3s1\MLOPS\iforest_pipeline(1)')

@app.route('/')
def index():
    return render_template('mlops2.html', result='', form_data={})

@app.route('/predict', methods=['POST'])
def predict_route():
    try:
        # Retrieve form inputs
        fiscal_year = request.form.get('FISCAL_YR', type=int)
        fiscal_month = request.form.get('FISCAL_MTH', type=int)
        div_name = request.form.get('DIV_NAME')
        merchant = request.form.get('MERCHANT')
        cat_desc = request.form.get('CAT_DESC')
        trans_dt = request.form.get('TRANS_DT')
        amt = request.form.get('AMT', type=float)

        # Print values for debugging
        print(f"fiscal_year: {fiscal_year}")
        print(f"fiscal_month: {fiscal_month}")
        print(f"div_name: {div_name}")
        print(f"merchant: {merchant}")
        print(f"cat_desc: {cat_desc}")
        print(f"trans_dt: {trans_dt}")
        print(f"amt: {amt}")

        # Check for missing values
        if any(v is None for v in [fiscal_year, fiscal_month, div_name, merchant, cat_desc, trans_dt, amt]):
            return render_template('mlops2.html', result='Error: Missing values in input data', form_data=request.form)

        # Prepare input data for prediction
        input_data = {
            'FISCAL_YR': [fiscal_year],
            'FISCAL_MTH': [fiscal_month],
            'DIV_NAME': [div_name],
            'MERCHANT': [merchant],
            'CAT_DESC': [cat_desc],
            'TRANS_DT': [trans_dt],
            'AMT': [amt]
        }

        # Convert to DataFrame
        input_df = pd.DataFrame(input_data)

        # Perform prediction
        prediction = predict_model(model, data=input_df)
        anomaly_score = prediction['Anomaly'].iloc[0] if 'Anomaly' in prediction.columns else None

        # Map prediction to a readable format
        if anomaly_score is not None:
            result = "1 (anomaly)" if anomaly_score == 1 else "0 (normal)"
        else:
            result = 'Prediction not available'

        return render_template('mlops2.html', result=result, form_data=request.form)

    except Exception as e:
        return render_template('mlops2.html', result=f'Error: {str(e)}', form_data=request.form)

if __name__ == '__main__':
    app.run(debug=True)

from flask import Flask, request, render_template
from pycaret.classification import load_model
import pandas as pd
import logging

app = Flask(__name__)

# Load the model
model = load_model(r"C:\Users\65881\MLOPS_Assignment\final_mushroom_model (1)")
logging.info("Transformation Pipeline and Model Successfully Loaded")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Collect only the selected data from the form input fields
    input_data = {
        'cap-shape': [request.form['cap-shape']],
        'odor': [request.form['odor']],
        'gill-size': [request.form['gill-size']],
        'spore-print-color': [request.form['spore-print-color']],
        'habitat': [request.form['habitat']]
    }

    # Convert input data to a DataFrame
    input_df = pd.DataFrame(input_data)

    # Log the input data for debugging
    logging.info(f"Input DataFrame: {input_df}")

    # Fill missing columns with default values
    all_columns = ['cap-shape', 'cap-surface', 'cap-color', 'bruises', 'odor',
                   'gill-attachment', 'gill-spacing', 'gill-size', 'gill-color',
                   'stalk-shape', 'stalk-root', 'stalk-surface-above-ring',
                   'stalk-surface-below-ring', 'stalk-color-above-ring',
                   'stalk-color-below-ring', 'veil-type', 'veil-color', 'ring-number',
                   'ring-type', 'spore-print-color', 'population', 'habitat']

    for col in all_columns:
        if col not in input_df.columns:
            input_df[col] = 'default_value'  # Replace 'default_value' with appropriate values

    # Log the adjusted input data
    logging.info(f"Adjusted Input DataFrame: {input_df}")

    # Make prediction
    prediction = model.predict(input_df)[0]

    # Log the prediction value for debugging
    logging.info(f"Prediction: {prediction}")

    # Generate result based on prediction
    if prediction == 0 or prediction == 'edible':
        result = "The mushroom is edible."
    else:
        result = "The mushroom is poisonous."

    return render_template('index.html', prediction_text=result)

if __name__ == "__main__":
    app.run(debug=True)

